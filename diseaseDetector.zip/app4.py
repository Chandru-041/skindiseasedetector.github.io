import streamlit as st
import os
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from keras.models import load_model
import numpy as np
import requests
from bs4 import BeautifulSoup
import json
import requests

def predict_disease(file_path):
    model = load_model('best_model.h5')
    target_sizes = [(28, 28), (256, 256) ,(224, 224)]
    for target_size in target_sizes:
        img = load_img(file_path, target_size=target_size)
        img = img_to_array(img) / 255.
        img = np.expand_dims(img, axis=0)
        preds = model.predict(img)
        preds = np.argmax(preds, axis=1)
        if preds[0] != 0:
            return preds[0]
    return 0


def get_suggestions(disease_name):
    query = "how to control " + disease_name + " naturally"
    api_key = "AIzaSyASN-ZnxcIaN2tcTBLNO-UHfjVXxccU0vc"
    search_engine_id = "73bf5192930804470"
    url = f"https://www.googleapis.com/customsearch/v1?q={query}&key={api_key}&cx={search_engine_id}"
    try:
        response = requests.get(url)
        search_results = json.loads(response.text)
        suggestions = []
        for result in search_results['items'][:3]:
            suggestions.append(result['link'])
        return suggestions
    except:
        return []


st.set_page_config(page_title="Skin Disease Detection")

st.title("Skin Disease Detection")

uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png", "gif"])


if uploaded_file is not None:
    image_path = os.path.join(os.getcwd(), 'uploads', "uploaded_image.jpg")
    with open(image_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    st.image(uploaded_file, caption='Uploaded Image', use_column_width=True)
    st.write("")
    st.write("Classifying...")
    disease_id = predict_disease(image_path)
    if disease_id == 0:
        disease_name = "Actinic keratoses and intraepithelial carcinoma / Bowen's disease"
    elif disease_id == 1:
        disease_name = "Basal cell carcinoma"
    elif disease_id == 2:
        disease_name = "Benign keratosis-like lesions (solar lentigines / seborrheic keratoses and lichen-planus like keratoses)"
    elif disease_id == 3:
        disease_name = "Dermatofibroma"
    elif disease_id == 4:
        disease_name = "Melanoma"
    elif disease_id == 5:
        disease_name = "Melanocytic nevi"
    elif disease_id == 6:
        disease_name = "Vascular lesions (angiomas, angiokeratomas, pyogenic granulomas and hemorrhage)"
    else:
        disease_name = "Not recognized"
    st.write(f"Detected Disease: {disease_name}")
    st.write("")
    st.write("Suggestions:")
    suggestions = get_suggestions(disease_name)
    if len(suggestions) == 0:
        st.write("Sorry, no suggestions found.")
    else:
        for i, suggestion in enumerate(suggestions):
            st.write(f"{i+1}. {suggestion}")
